INSERT INTO account_comp(balance, id_account) VALUES (100000, 1) ON CONFLICT DO NOTHING;
INSERT INTO account_comp(balance, id_account) VALUES (200000, 2) ON CONFLICT DO NOTHING;
INSERT INTO account_comp(balance, id_account) VALUES (0, 3) ON CONFLICT DO NOTHING;
INSERT INTO account_impl(balance, id_account) VALUES (300000, 4) ON CONFLICT DO NOTHING;

INSERT INTO account_impl (id_account) VALUES (1) ON CONFLICT DO NOTHING;
INSERT INTO account_impl (id_account) VALUES (2) ON CONFLICT DO NOTHING;
INSERT INTO account_impl (id_account) VALUES (3) ON CONFLICT DO NOTHING;
INSERT INTO account_impl (id_account) VALUES (4) ON CONFLICT DO NOTHING;


